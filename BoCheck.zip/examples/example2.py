from BoCheck.process import process_text

if __name__ == '__main__':
    text = "ཀྭའི"
    process_text(text, table_path="demo.csv")
    